import React, {Component} from 'react'
import Create from './components/Create/Create'

class App extends Component {
    render() {
        return (
            <>
                <Create />
            </>
        )
    }
}

export default App